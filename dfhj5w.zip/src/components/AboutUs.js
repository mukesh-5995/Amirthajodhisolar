import React from "react";
//import "./AboutUs.css";

const AboutUs = () => {
  return (
    <div className="about-us" id="about">
      <h2>About Us</h2>
      <p>
        We are a company dedicated to providing excellent services and customer
        satisfaction. Our team is committed to delivering quality work and
        exceptional results.
      </p>
    </div>
  );
};

export default AboutUs;
